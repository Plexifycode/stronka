(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/components/navigator.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
const Navigator = (param)=>{
    let { activeIndex, setActiveIndex, pageIndexes } = param;
    _s();
    const [isNavbarHidden, setIsNavbarHidden] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const slideNavUp = ()=>{
        setIsNavbarHidden(false);
    };
    const slideNavDown = ()=>{
        setIsNavbarHidden(true);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        onMouseEnter: slideNavUp,
        onMouseLeave: slideNavDown,
        className: "\n         \n      grid grid-rows-1 grid-flow-col auto-cols-[3rem] fixed left-1/2 -translate-x-1/2 -bottom-2 z-999  drop-shadow-[0_0_8px] drop-shadow-black/40 backdrop-blur-md transition-all duration-300 h-20 px-8 place-items-center bg-white/10 rounded-t-2xl\n      ".concat(isNavbarHidden ? "translate-y-3/4" : "", "\n      \n      "),
        children: pageIndexes.map((_, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "\n            ".concat(activeIndex !== index ? "bg-white/40 hover:bg-white/60 active:bg-white/80 active:scale-120 " : "bg-green-300/40 hover:bg-green-300/60 scale-130 active:bg-green-300/80", "\n            w-6 aspect-square z-5 rounded-full  hover:scale-140 hover:cursor-pointer active:blur-[1px]  transition-all duration-250 active:duration-75\n            "),
                onClick: ()=>{
                    setActiveIndex(index);
                }
            }, index, false, {
                fileName: "[project]/app/components/navigator.js",
                lineNumber: 27,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0)))
    }, void 0, false, {
        fileName: "[project]/app/components/navigator.js",
        lineNumber: 17,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(Navigator, "2a6O7pkB65i3SpkBjeR1TeHKj94=");
_c = Navigator;
const __TURBOPACK__default__export__ = Navigator;
var _c;
__turbopack_context__.k.register(_c, "Navigator");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/api/spotify/web.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "albumIDs",
    ()=>albumIDs,
    "albumsData",
    ()=>albumsData,
    "featuredArtistsData",
    ()=>featuredArtistsData,
    "getAlbumID",
    ()=>getAlbumID,
    "getAlbumsData",
    ()=>getAlbumsData,
    "getArtistsData",
    ()=>getArtistsData,
    "getBearerToken",
    ()=>getBearerToken
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
async function getBearerToken() {
    const env_client_id = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.SPOTIFY_CLIENT_ID;
    const env_client_secret = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.SPOTIFY_CLIENT_SECRET;
    let bearer_token = null;
    try {
        const response = await fetch("https://accounts.spotify.com/api/token", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: new URLSearchParams({
                grant_type: "client_credentials",
                client_id: env_client_id,
                client_secret: env_client_secret
            })
        });
        if (!response.ok) {
            throw new Error("Spotify API error: ".concat(response.statusText));
        }
        bearer_token = await response.json();
        return bearer_token;
    } catch (error) {
        console.error("can't get bearer :( ", error);
    }
}
let access_token = null;
await getBearerToken().then((data)=>{
    access_token = data.access_token;
});
async function getAlbumID(query) {
    try {
        const response = await fetch("https://api.spotify.com/v1/search?q=".concat(query, "&limit=1&artist=Taco%2520Hemingway&type=album&market=PL"), {
            method: "GET",
            headers: {
                Authorization: "Bearer ".concat(access_token)
            }
        });
        if (!response.ok) {
            throw new Error("Spotify API error: ".concat(response.statusText, ")"));
        }
        return response.json();
    } catch (error) {
        console.error("cant get data", error);
    }
}
let albumIDs = [];
const albumNames = [
    "trojkat warszawski",
    "marmur",
    "0,25mg",
    "cafe belga",
    "jarmark",
    "1-800oswiecenie"
];
async function fillAlbumIDs() {
    for(let i = 0; i < albumNames.length; i++){
        let albumID = null;
        await getAlbumID(albumNames[i]).then((data)=>{
            const albumURI = data["albums"]["items"][0]["uri"];
            albumID = albumURI.replace("spotify:album:", "");
        });
        albumIDs.push(albumID);
    }
}
await fillAlbumIDs();
let albumsData = [];
async function getAlbumsData() {
    let ids = "";
    for(let i = 0; i < albumIDs.length; i++){
        const albumID = albumIDs[i];
        ids += albumID;
        if (i !== albumIDs.length - 1) {
            ids += ",";
        }
    }
    try {
        const response = await fetch("https://api.spotify.com/v1/albums?ids=".concat(ids), {
            method: "GET",
            headers: {
                Authorization: "Bearer ".concat(access_token)
            }
        });
        if (!response.ok) {
            throw new Error("Spotify API error: ".concat(response.statusText, ")"));
        }
        return response.json();
    } catch (error) {
        console.error("cant get data", error);
    }
}
await getAlbumsData().then((data)=>{
    albumsData = data["albums"];
});
const excludedArtists = [
    "Taco Hemingway",
    "TACONAFIDE",
    "Lanek",
    "Gruby Mielzky",
    "Borucci",
    "Kacha",
    "Bebun",
    "Zeppy Zep",
    "@atutowy"
];
let featuredArtists = [];
let allFeaturedArtists = [];
let featuredArtistsData = [];
for(let i = 0; i < albumsData.length; i++){
    const albumSongs = albumsData[i]["tracks"]["items"];
    featuredArtists.push(new Array());
    for(let j = 0; j < albumSongs.length; j++){
        const songArtists = albumSongs[j]["artists"];
        for(let k = 0; k < songArtists.length; k++){
            const artistName = songArtists[k]["name"];
            const artistID = songArtists[k]["id"];
            if (excludedArtists.includes(artistName)) {
                continue;
            }
            if (featuredArtists[i].includes(artistName)) {
                continue;
            }
            featuredArtists[i].push(artistID);
        }
    }
}
for(let i = 0; i < featuredArtists.length; i++){
    if (featuredArtists[i].length === 0) {
        continue;
    }
    for(let j = 0; j < featuredArtists[i].length; j++){
        if (allFeaturedArtists.includes(featuredArtists[i][j])) {
            continue;
        }
        allFeaturedArtists.push(featuredArtists[i][j]);
    }
}
let allArtistsData = [];
async function getArtistsData() {
    let ids = "";
    for(let i = 0; i < allFeaturedArtists.length; i++){
        const artist = allFeaturedArtists[i];
        ids += artist;
        if (i !== allFeaturedArtists.length - 1) {
            ids += ",";
        }
    }
    try {
        const response = await fetch("https://api.spotify.com/v1/artists?ids=".concat(ids), {
            method: "GET",
            headers: {
                Authorization: "Bearer ".concat(access_token)
            }
        });
        if (!response.ok) {
            throw new Error("Spotify API error: ".concat(response.statusText, ")"));
        }
        return response.json();
    } catch (error) {
        console.error("cant get data", error);
    }
}
await getArtistsData().then((data)=>{
    allArtistsData = data["artists"];
});
for(let i = 0; i < featuredArtists.length; i++){
    featuredArtistsData.push(new Array());
    if (featuredArtists[i].length === 0) {
        continue;
    }
    for(let j = 0; j < featuredArtists[i].length; j++){
        const foundObject = allArtistsData.find((obj)=>obj["id"] === featuredArtists[i][j]);
        if (!foundObject) {
            console.error("can't find object :(");
            continue;
        }
        if (featuredArtistsData[i].includes(foundObject)) {
            continue;
        }
        featuredArtistsData[i].push(foundObject);
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[project]/app/components/PagesContainer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$spotify$2f$web$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/spotify/web.js [app-client] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$spotify$2f$web$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__
]);
[__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$spotify$2f$web$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const albumDescriptions = [
    'Trójkąt warszawski spotkał się ze znakomitymi ocenami krytyków muzycznych. Recenzenci chwalili go za błyskotliwe teksty i dobrze dobrane produkcje muzyczne, ciekawie opowiedzianą historię oraz za wprowadzenie nowości na polski rynek muzyczny. Album po czasie odniósł sukces komercyjny, odnotowując wysokie wyniki odtworzeń w serwisach streamingowych i debiutując na trzecim miejscu ogólnopolskiej listy sprzedaży OLiS.',
    'Marmur to pierwszy album studyjny Taco Hemingwaya, stanowiący konceptualne słuchowisko osadzone w fikcyjnym, tajemniczym Hotelu Marmur w Trójmieście. Album jest mroczniejszy i bardziej melancholijny od poprzednich wydawnictw, a jego spójna narracja, pełna trafnych metafor i obserwacji, czyni go czymś w rodzaju muzycznej powieści.',
    '"0,25 mg" to mixtape duetu Taconafide (Taco Hemingway i Quebonafide), który pierwotnie ukazał się w 2018 roku jako bonus do ich głównego albumu, "Soma 0,5 mg". Mimo swojej pierwotnie dodatkowej natury, materiał ten zawiera kilkanaście pełnoprawnych utworów, utrzymanych w konwencji rapu i hip-hopu, stanowiąc równorzędną część kolaboracji.',
    '"Café Belga" to drugi długogrający album Taco Hemingwaya, zaskakująco wypuszczony bez wcześniejszych zapowiedzi. Album, nagrany w Brukseli i Warszawie, wplecione ma fragmenty wywiadu udzielonego przez rapera w tytułowej kawiarni, co nadaje mu formę spójnego słuchowiska. Muzycznie łączy hip-hop z elementami trapu i popu.',
    'Jarmark to czwarta studyjna płyta artysty, która stanowi mocną, często krytyczną recenzję współczesnej Polski, jej historii po transformacji i mentalności społecznej. Pod względem muzycznym to hip-hop z wpływami alternatywnymi, który bywa odbierany przez krytyków jako nierówny, ale lirycznie sprawny i pełen społecznych obserwacji.',
    '“1-800-OŚWIECENIE” to album konceptualny, ale nie w charakterze fabularnym, tak jak było to w przypadku wcześniejszego “Marmuru”. Na nową płytę składa się 15 premierowych utworów, a sam album w zaledwie dobę po starcie preorderu osiągnął złoty nakład (ponad 15 tys. sprzedanych egzemplarzy).'
];
const PagesContainer = (param)=>{
    let { activeIndex, setActiveIndex } = param;
    _s();
    const ContainerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PagesContainer.useEffect": ()=>{
            if (ContainerRef.current) {
                setTimeout({
                    "PagesContainer.useEffect": ()=>{
                        const totalChildren = ContainerRef.current.children.length;
                        const pageCount = totalChildren - 1;
                        const newIndexes = [
                            ...Array(pageCount).keys()
                        ];
                        setPageIndexes(newIndexes);
                        console.log("Liczba zliczonych stron: ".concat(pageCount, "."));
                    }
                }["PagesContainer.useEffect"], 0);
            }
        }
    }["PagesContainer.useEffect"], []);
    // Obliczanie transformacji
    const transformStyle = "translateX(-".concat(activeIndex * 100, "vw)");
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ContainerRef,
        id: "app",
        style: {
            transform: transformStyle
        },
        className: "absolute left-0 top-0 grid auto-cols-[100vw] grid-rows-1 grid-flow-col h-full w-full overflow-visible transition-all duration-420 ease-in-out",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MainPage, {}, void 0, false, {
                fileName: "[project]/app/components/PagesContainer.js",
                lineNumber: 46,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$spotify$2f$web$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["albumsData"].map((_, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AlbumPage, {
                    albumInfo: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$spotify$2f$web$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["albumsData"][index],
                    albumDescription: albumDescriptions[index],
                    featuredArtists: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$spotify$2f$web$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["featuredArtistsData"][index]
                }, index, false, {
                    fileName: "[project]/app/components/PagesContainer.js",
                    lineNumber: 49,
                    columnNumber: 17
                }, ("TURBOPACK compile-time value", void 0)))
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/PagesContainer.js",
        lineNumber: 39,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(PagesContainer, "9S4JCGpKxC+E5aoAlN/lK9hNWPU=");
_c = PagesContainer;
const __TURBOPACK__default__export__ = PagesContainer;
var _c;
__turbopack_context__.k.register(_c, "PagesContainer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/app/components/Nigga.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$navigator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/navigator.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$PagesContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/PagesContainer.js [app-client] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$PagesContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__
]);
[__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$PagesContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const Nigga = ()=>{
    _s();
    const [activeIndex, setActiveIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [pageIndexes, setPageIndexes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$PagesContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                activeIndex: activeIndex,
                setActiveIndex: setActiveIndex
            }, void 0, false, {
                fileName: "[project]/app/components/Nigga.js",
                lineNumber: 14,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$navigator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                activeIndex: activeIndex,
                setActiveIndex: setActiveIndex,
                pageIndexes: pageIndexes
            }, void 0, false, {
                fileName: "[project]/app/components/Nigga.js",
                lineNumber: 16,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
_s(Nigga, "S1uZbbdAohFPHJkHoLa+kR+WZy0=");
_c = Nigga;
const __TURBOPACK__default__export__ = Nigga;
var _c;
__turbopack_context__.k.register(_c, "Nigga");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/node_modules/next/dist/compiled/react/cjs/react-jsx-dev-runtime.development.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * @license React
 * react-jsx-dev-runtime.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
"production" !== ("TURBOPACK compile-time value", "development") && function() {
    function getComponentNameFromType(type) {
        if (null == type) return null;
        if ("function" === typeof type) return type.$$typeof === REACT_CLIENT_REFERENCE ? null : type.displayName || type.name || null;
        if ("string" === typeof type) return type;
        switch(type){
            case REACT_FRAGMENT_TYPE:
                return "Fragment";
            case REACT_PROFILER_TYPE:
                return "Profiler";
            case REACT_STRICT_MODE_TYPE:
                return "StrictMode";
            case REACT_SUSPENSE_TYPE:
                return "Suspense";
            case REACT_SUSPENSE_LIST_TYPE:
                return "SuspenseList";
            case REACT_ACTIVITY_TYPE:
                return "Activity";
        }
        if ("object" === typeof type) switch("number" === typeof type.tag && console.error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), type.$$typeof){
            case REACT_PORTAL_TYPE:
                return "Portal";
            case REACT_CONTEXT_TYPE:
                return type.displayName || "Context";
            case REACT_CONSUMER_TYPE:
                return (type._context.displayName || "Context") + ".Consumer";
            case REACT_FORWARD_REF_TYPE:
                var innerType = type.render;
                type = type.displayName;
                type || (type = innerType.displayName || innerType.name || "", type = "" !== type ? "ForwardRef(" + type + ")" : "ForwardRef");
                return type;
            case REACT_MEMO_TYPE:
                return innerType = type.displayName || null, null !== innerType ? innerType : getComponentNameFromType(type.type) || "Memo";
            case REACT_LAZY_TYPE:
                innerType = type._payload;
                type = type._init;
                try {
                    return getComponentNameFromType(type(innerType));
                } catch (x) {}
        }
        return null;
    }
    function testStringCoercion(value) {
        return "" + value;
    }
    function checkKeyStringCoercion(value) {
        try {
            testStringCoercion(value);
            var JSCompiler_inline_result = !1;
        } catch (e) {
            JSCompiler_inline_result = !0;
        }
        if (JSCompiler_inline_result) {
            JSCompiler_inline_result = console;
            var JSCompiler_temp_const = JSCompiler_inline_result.error;
            var JSCompiler_inline_result$jscomp$0 = "function" === typeof Symbol && Symbol.toStringTag && value[Symbol.toStringTag] || value.constructor.name || "Object";
            JSCompiler_temp_const.call(JSCompiler_inline_result, "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.", JSCompiler_inline_result$jscomp$0);
            return testStringCoercion(value);
        }
    }
    function getTaskName(type) {
        if (type === REACT_FRAGMENT_TYPE) return "<>";
        if ("object" === typeof type && null !== type && type.$$typeof === REACT_LAZY_TYPE) return "<...>";
        try {
            var name = getComponentNameFromType(type);
            return name ? "<" + name + ">" : "<...>";
        } catch (x) {
            return "<...>";
        }
    }
    function getOwner() {
        var dispatcher = ReactSharedInternals.A;
        return null === dispatcher ? null : dispatcher.getOwner();
    }
    function UnknownOwner() {
        return Error("react-stack-top-frame");
    }
    function hasValidKey(config) {
        if (hasOwnProperty.call(config, "key")) {
            var getter = Object.getOwnPropertyDescriptor(config, "key").get;
            if (getter && getter.isReactWarning) return !1;
        }
        return void 0 !== config.key;
    }
    function defineKeyPropWarningGetter(props, displayName) {
        function warnAboutAccessingKey() {
            specialPropKeyWarningShown || (specialPropKeyWarningShown = !0, console.error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)", displayName));
        }
        warnAboutAccessingKey.isReactWarning = !0;
        Object.defineProperty(props, "key", {
            get: warnAboutAccessingKey,
            configurable: !0
        });
    }
    function elementRefGetterWithDeprecationWarning() {
        var componentName = getComponentNameFromType(this.type);
        didWarnAboutElementRef[componentName] || (didWarnAboutElementRef[componentName] = !0, console.error("Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."));
        componentName = this.props.ref;
        return void 0 !== componentName ? componentName : null;
    }
    function ReactElement(type, key, props, owner, debugStack, debugTask) {
        var refProp = props.ref;
        type = {
            $$typeof: REACT_ELEMENT_TYPE,
            type: type,
            key: key,
            props: props,
            _owner: owner
        };
        null !== (void 0 !== refProp ? refProp : null) ? Object.defineProperty(type, "ref", {
            enumerable: !1,
            get: elementRefGetterWithDeprecationWarning
        }) : Object.defineProperty(type, "ref", {
            enumerable: !1,
            value: null
        });
        type._store = {};
        Object.defineProperty(type._store, "validated", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: 0
        });
        Object.defineProperty(type, "_debugInfo", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: null
        });
        Object.defineProperty(type, "_debugStack", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: debugStack
        });
        Object.defineProperty(type, "_debugTask", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: debugTask
        });
        Object.freeze && (Object.freeze(type.props), Object.freeze(type));
        return type;
    }
    function jsxDEVImpl(type, config, maybeKey, isStaticChildren, debugStack, debugTask) {
        var children = config.children;
        if (void 0 !== children) if (isStaticChildren) if (isArrayImpl(children)) {
            for(isStaticChildren = 0; isStaticChildren < children.length; isStaticChildren++)validateChildKeys(children[isStaticChildren]);
            Object.freeze && Object.freeze(children);
        } else console.error("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
        else validateChildKeys(children);
        if (hasOwnProperty.call(config, "key")) {
            children = getComponentNameFromType(type);
            var keys = Object.keys(config).filter(function(k) {
                return "key" !== k;
            });
            isStaticChildren = 0 < keys.length ? "{key: someKey, " + keys.join(": ..., ") + ": ...}" : "{key: someKey}";
            didWarnAboutKeySpread[children + isStaticChildren] || (keys = 0 < keys.length ? "{" + keys.join(": ..., ") + ": ...}" : "{}", console.error('A props object containing a "key" prop is being spread into JSX:\n  let props = %s;\n  <%s {...props} />\nReact keys must be passed directly to JSX without using spread:\n  let props = %s;\n  <%s key={someKey} {...props} />', isStaticChildren, children, keys, children), didWarnAboutKeySpread[children + isStaticChildren] = !0);
        }
        children = null;
        void 0 !== maybeKey && (checkKeyStringCoercion(maybeKey), children = "" + maybeKey);
        hasValidKey(config) && (checkKeyStringCoercion(config.key), children = "" + config.key);
        if ("key" in config) {
            maybeKey = {};
            for(var propName in config)"key" !== propName && (maybeKey[propName] = config[propName]);
        } else maybeKey = config;
        children && defineKeyPropWarningGetter(maybeKey, "function" === typeof type ? type.displayName || type.name || "Unknown" : type);
        return ReactElement(type, children, maybeKey, getOwner(), debugStack, debugTask);
    }
    function validateChildKeys(node) {
        "object" === typeof node && null !== node && node.$$typeof === REACT_ELEMENT_TYPE && node._store && (node._store.validated = 1);
    }
    var React = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"), REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"), REACT_PORTAL_TYPE = Symbol.for("react.portal"), REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"), REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"), REACT_PROFILER_TYPE = Symbol.for("react.profiler"), REACT_CONSUMER_TYPE = Symbol.for("react.consumer"), REACT_CONTEXT_TYPE = Symbol.for("react.context"), REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"), REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"), REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"), REACT_MEMO_TYPE = Symbol.for("react.memo"), REACT_LAZY_TYPE = Symbol.for("react.lazy"), REACT_ACTIVITY_TYPE = Symbol.for("react.activity"), REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference"), ReactSharedInternals = React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, hasOwnProperty = Object.prototype.hasOwnProperty, isArrayImpl = Array.isArray, createTask = console.createTask ? console.createTask : function() {
        return null;
    };
    React = {
        react_stack_bottom_frame: function(callStackForError) {
            return callStackForError();
        }
    };
    var specialPropKeyWarningShown;
    var didWarnAboutElementRef = {};
    var unknownOwnerDebugStack = React.react_stack_bottom_frame.bind(React, UnknownOwner)();
    var unknownOwnerDebugTask = createTask(getTaskName(UnknownOwner));
    var didWarnAboutKeySpread = {};
    exports.Fragment = REACT_FRAGMENT_TYPE;
    exports.jsxDEV = function(type, config, maybeKey, isStaticChildren) {
        var trackActualOwner = 1e4 > ReactSharedInternals.recentlyCreatedOwnerStacks++;
        return jsxDEVImpl(type, config, maybeKey, isStaticChildren, trackActualOwner ? Error("react-stack-top-frame") : unknownOwnerDebugStack, trackActualOwner ? createTask(getTaskName(type)) : unknownOwnerDebugTask);
    };
}();
}),
"[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/cjs/react-jsx-dev-runtime.development.js [app-client] (ecmascript)");
}
}),
]);

//# sourceMappingURL=_1674e1b0._.js.map