module.exports = [
"[project]/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[project]/app/layout.js [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.js [app-rsc] (ecmascript)"));
}),
"[project]/app/api/spotify/web.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "albumIDs",
    ()=>albumIDs,
    "albumsData",
    ()=>albumsData,
    "featuredArtistsData",
    ()=>featuredArtistsData,
    "getAlbumID",
    ()=>getAlbumID,
    "getAlbumsData",
    ()=>getAlbumsData,
    "getArtistsData",
    ()=>getArtistsData,
    "getBearerToken",
    ()=>getBearerToken
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
;
async function getBearerToken() {
    const env_client_id = process.env.SPOTIFY_CLIENT_ID;
    const env_client_secret = process.env.SPOTIFY_CLIENT_SECRET;
    let bearer_token = null;
    try {
        const response = await fetch("https://accounts.spotify.com/api/token", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: new URLSearchParams({
                grant_type: "client_credentials",
                client_id: env_client_id,
                client_secret: env_client_secret
            })
        });
        if (!response.ok) {
            throw new Error(`Spotify API error: ${response.statusText}`);
        }
        bearer_token = await response.json();
        return bearer_token;
    } catch (error) {
        console.error("can't get bearer :( ", error);
    }
}
let access_token = null;
await getBearerToken().then((data)=>{
    access_token = data.access_token;
});
async function getAlbumID(query) {
    try {
        const response = await fetch(`https://api.spotify.com/v1/search?q=${query}&limit=1&artist=Taco%2520Hemingway&type=album&market=PL`, {
            method: "GET",
            headers: {
                Authorization: `Bearer ${access_token}`
            }
        });
        if (!response.ok) {
            throw new Error(`Spotify API error: ${response.statusText})`);
        }
        return response.json();
    } catch (error) {
        console.error("cant get data", error);
    }
}
let albumIDs = [];
const albumNames = [
    "trojkat warszawski",
    "marmur",
    "0,25mg",
    "cafe belga",
    "jarmark",
    "1-800oswiecenie"
];
async function fillAlbumIDs() {
    for(let i = 0; i < albumNames.length; i++){
        let albumID = null;
        await getAlbumID(albumNames[i]).then((data)=>{
            const albumURI = data["albums"]["items"][0]["uri"];
            albumID = albumURI.replace("spotify:album:", "");
        });
        albumIDs.push(albumID);
    }
}
await fillAlbumIDs();
let albumsData = [];
async function getAlbumsData() {
    let ids = "";
    for(let i = 0; i < albumIDs.length; i++){
        const albumID = albumIDs[i];
        ids += albumID;
        if (i !== albumIDs.length - 1) {
            ids += ",";
        }
    }
    try {
        const response = await fetch(`https://api.spotify.com/v1/albums?ids=${ids}`, {
            method: "GET",
            headers: {
                Authorization: `Bearer ${access_token}`
            }
        });
        if (!response.ok) {
            throw new Error(`Spotify API error: ${response.statusText})`);
        }
        return response.json();
    } catch (error) {
        console.error("cant get data", error);
    }
}
await getAlbumsData().then((data)=>{
    albumsData = data["albums"];
});
const excludedArtists = [
    "Taco Hemingway",
    "TACONAFIDE",
    "Lanek",
    "Gruby Mielzky",
    "Borucci",
    "Kacha",
    "Bebun",
    "Zeppy Zep",
    "@atutowy"
];
let featuredArtists = [];
let allFeaturedArtists = [];
let featuredArtistsData = [];
for(let i = 0; i < albumsData.length; i++){
    const albumSongs = albumsData[i]["tracks"]["items"];
    featuredArtists.push(new Array());
    for(let j = 0; j < albumSongs.length; j++){
        const songArtists = albumSongs[j]["artists"];
        for(let k = 0; k < songArtists.length; k++){
            const artistName = songArtists[k]["name"];
            const artistID = songArtists[k]["id"];
            if (excludedArtists.includes(artistName)) {
                continue;
            }
            if (featuredArtists[i].includes(artistName)) {
                continue;
            }
            featuredArtists[i].push(artistID);
        }
    }
}
for(let i = 0; i < featuredArtists.length; i++){
    if (featuredArtists[i].length === 0) {
        continue;
    }
    for(let j = 0; j < featuredArtists[i].length; j++){
        if (allFeaturedArtists.includes(featuredArtists[i][j])) {
            continue;
        }
        allFeaturedArtists.push(featuredArtists[i][j]);
    }
}
let allArtistsData = [];
async function getArtistsData() {
    let ids = "";
    for(let i = 0; i < allFeaturedArtists.length; i++){
        const artist = allFeaturedArtists[i];
        ids += artist;
        if (i !== allFeaturedArtists.length - 1) {
            ids += ",";
        }
    }
    try {
        const response = await fetch(`https://api.spotify.com/v1/artists?ids=${ids}`, {
            method: "GET",
            headers: {
                Authorization: `Bearer ${access_token}`
            }
        });
        if (!response.ok) {
            throw new Error(`Spotify API error: ${response.statusText})`);
        }
        return response.json();
    } catch (error) {
        console.error("cant get data", error);
    }
}
await getArtistsData().then((data)=>{
    allArtistsData = data["artists"];
});
for(let i = 0; i < featuredArtists.length; i++){
    featuredArtistsData.push(new Array());
    if (featuredArtists[i].length === 0) {
        continue;
    }
    for(let j = 0; j < featuredArtists[i].length; j++){
        const foundObject = allArtistsData.find((obj)=>obj["id"] === featuredArtists[i][j]);
        if (!foundObject) {
            console.error("can't find object :(");
            continue;
        }
        if (featuredArtistsData[i].includes(foundObject)) {
            continue;
        }
        featuredArtistsData[i].push(foundObject);
    }
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[project]/app/page.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module '../components/AlbumPage'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '../components/Navigator'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '../components/MainPage'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '@/public/assets/trojkat_warszawski_cover.jpg'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '@/public/assets/025mg_cover.jpg'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '@/public/assets/cafe_belga_cover.jpg'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '@/public/assets/jarmark_cover.jpg'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '@/public/assets/1-800_oswiecenie_cover.jpg'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$spotify$2f$web$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/spotify/web.js [app-rsc] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$spotify$2f$web$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__
]);
[__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$spotify$2f$web$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
;
;
;
;
;
;
;
;
;
;
function Home() {
    console.log(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$spotify$2f$web$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["albumData"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        id: "app",
        className: "absolute left-0 top-0 grid auto-cols-[100vw] grid-rows-1 grid-flow-col h-full w-full overflow-visible transition-all duration-420 ease-in-out",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(MainPage, {}, void 0, false, {
                fileName: "[project]/app/page.js",
                lineNumber: 23,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(AlbumPage, {
                imgsrc: albumCover1
            }, void 0, false, {
                fileName: "[project]/app/page.js",
                lineNumber: 24,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(AlbumPage, {
                imgsrc: albumCover2
            }, void 0, false, {
                fileName: "[project]/app/page.js",
                lineNumber: 25,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(AlbumPage, {
                imgsrc: albumCover3
            }, void 0, false, {
                fileName: "[project]/app/page.js",
                lineNumber: 26,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(AlbumPage, {
                imgsrc: albumCover4
            }, void 0, false, {
                fileName: "[project]/app/page.js",
                lineNumber: 27,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(AlbumPage, {
                imgsrc: albumCover5
            }, void 0, false, {
                fileName: "[project]/app/page.js",
                lineNumber: 28,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(Navigator, {}, void 0, false, {
                fileName: "[project]/app/page.js",
                lineNumber: 30,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/page.js",
        lineNumber: 20,
        columnNumber: 9
    }, this);
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/app/page.js [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/page.js [app-rsc] (ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__9c397a07._.js.map