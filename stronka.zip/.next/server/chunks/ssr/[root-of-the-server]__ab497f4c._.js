module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/app/components/navigator.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
const Navigator = ({ activeIndex, setActiveIndex, pageIndexes })=>{
    const [isNavbarHidden, setIsNavbarHidden] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    const slideNavUp = ()=>{
        setIsNavbarHidden(false);
    };
    const slideNavDown = ()=>{
        setIsNavbarHidden(true);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        onMouseEnter: slideNavUp,
        onMouseLeave: slideNavDown,
        className: `
         
      grid grid-rows-1 grid-flow-col auto-cols-[3rem] fixed left-1/2 -translate-x-1/2 -bottom-2 z-999  drop-shadow-[0_0_8px] drop-shadow-black/40 backdrop-blur-md transition-all duration-300 h-20 px-8 place-items-center bg-white/10 rounded-t-2xl
      ${isNavbarHidden ? "translate-y-3/4" : ""}
      
      `,
        children: pageIndexes.map((_, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `
            ${activeIndex !== index ? "bg-white/40 hover:bg-white/60 active:bg-white/80 active:scale-120 " : "bg-green-300/40 hover:bg-green-300/60 scale-130 active:bg-green-300/80"}
            w-6 aspect-square z-5 rounded-full  hover:scale-140 hover:cursor-pointer active:blur-[1px]  transition-all duration-250 active:duration-75
            `,
                onClick: ()=>{
                    setActiveIndex(index);
                }
            }, index, false, {
                fileName: "[project]/app/components/navigator.js",
                lineNumber: 27,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0)))
    }, void 0, false, {
        fileName: "[project]/app/components/navigator.js",
        lineNumber: 17,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = Navigator;
}),
"[project]/app/api/spotify/web.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "albumIDs",
    ()=>albumIDs,
    "albumsData",
    ()=>albumsData,
    "featuredArtistsData",
    ()=>featuredArtistsData,
    "getAlbumID",
    ()=>getAlbumID,
    "getAlbumsData",
    ()=>getAlbumsData,
    "getArtistsData",
    ()=>getArtistsData,
    "getBearerToken",
    ()=>getBearerToken
]);
async function getBearerToken() {
    const env_client_id = process.env.SPOTIFY_CLIENT_ID;
    const env_client_secret = process.env.SPOTIFY_CLIENT_SECRET;
    let bearer_token = null;
    try {
        const response = await fetch("https://accounts.spotify.com/api/token", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: new URLSearchParams({
                grant_type: "client_credentials",
                client_id: env_client_id,
                client_secret: env_client_secret
            })
        });
        if (!response.ok) {
            throw new Error(`Spotify API error: ${response.statusText}`);
        }
        bearer_token = await response.json();
        return bearer_token;
    } catch (error) {
        console.error("can't get bearer :( ", error);
    }
}
let access_token = null;
await getBearerToken().then((data)=>{
    access_token = data.access_token;
});
async function getAlbumID(query) {
    try {
        const response = await fetch(`https://api.spotify.com/v1/search?q=${query}&limit=1&artist=Taco%2520Hemingway&type=album&market=PL`, {
            method: "GET",
            headers: {
                Authorization: `Bearer ${access_token}`
            }
        });
        if (!response.ok) {
            throw new Error(`Spotify API error: ${response.statusText})`);
        }
        return response.json();
    } catch (error) {
        console.error("cant get data", error);
    }
}
let albumIDs = [];
const albumNames = [
    "trojkat warszawski",
    "marmur",
    "0,25mg",
    "cafe belga",
    "jarmark",
    "1-800oswiecenie"
];
async function fillAlbumIDs() {
    for(let i = 0; i < albumNames.length; i++){
        let albumID = null;
        await getAlbumID(albumNames[i]).then((data)=>{
            const albumURI = data["albums"]["items"][0]["uri"];
            albumID = albumURI.replace("spotify:album:", "");
        });
        albumIDs.push(albumID);
    }
}
await fillAlbumIDs();
let albumsData = [];
async function getAlbumsData() {
    let ids = "";
    for(let i = 0; i < albumIDs.length; i++){
        const albumID = albumIDs[i];
        ids += albumID;
        if (i !== albumIDs.length - 1) {
            ids += ",";
        }
    }
    try {
        const response = await fetch(`https://api.spotify.com/v1/albums?ids=${ids}`, {
            method: "GET",
            headers: {
                Authorization: `Bearer ${access_token}`
            }
        });
        if (!response.ok) {
            throw new Error(`Spotify API error: ${response.statusText})`);
        }
        return response.json();
    } catch (error) {
        console.error("cant get data", error);
    }
}
await getAlbumsData().then((data)=>{
    albumsData = data["albums"];
});
const excludedArtists = [
    "Taco Hemingway",
    "TACONAFIDE",
    "Lanek",
    "Gruby Mielzky",
    "Borucci",
    "Kacha",
    "Bebun",
    "Zeppy Zep",
    "@atutowy"
];
let featuredArtists = [];
let allFeaturedArtists = [];
let featuredArtistsData = [];
for(let i = 0; i < albumsData.length; i++){
    const albumSongs = albumsData[i]["tracks"]["items"];
    featuredArtists.push(new Array());
    for(let j = 0; j < albumSongs.length; j++){
        const songArtists = albumSongs[j]["artists"];
        for(let k = 0; k < songArtists.length; k++){
            const artistName = songArtists[k]["name"];
            const artistID = songArtists[k]["id"];
            if (excludedArtists.includes(artistName)) {
                continue;
            }
            if (featuredArtists[i].includes(artistName)) {
                continue;
            }
            featuredArtists[i].push(artistID);
        }
    }
}
for(let i = 0; i < featuredArtists.length; i++){
    if (featuredArtists[i].length === 0) {
        continue;
    }
    for(let j = 0; j < featuredArtists[i].length; j++){
        if (allFeaturedArtists.includes(featuredArtists[i][j])) {
            continue;
        }
        allFeaturedArtists.push(featuredArtists[i][j]);
    }
}
let allArtistsData = [];
async function getArtistsData() {
    let ids = "";
    for(let i = 0; i < allFeaturedArtists.length; i++){
        const artist = allFeaturedArtists[i];
        ids += artist;
        if (i !== allFeaturedArtists.length - 1) {
            ids += ",";
        }
    }
    try {
        const response = await fetch(`https://api.spotify.com/v1/artists?ids=${ids}`, {
            method: "GET",
            headers: {
                Authorization: `Bearer ${access_token}`
            }
        });
        if (!response.ok) {
            throw new Error(`Spotify API error: ${response.statusText})`);
        }
        return response.json();
    } catch (error) {
        console.error("cant get data", error);
    }
}
await getArtistsData().then((data)=>{
    allArtistsData = data["artists"];
});
for(let i = 0; i < featuredArtists.length; i++){
    featuredArtistsData.push(new Array());
    if (featuredArtists[i].length === 0) {
        continue;
    }
    for(let j = 0; j < featuredArtists[i].length; j++){
        const foundObject = allArtistsData.find((obj)=>obj["id"] === featuredArtists[i][j]);
        if (!foundObject) {
            console.error("can't find object :(");
            continue;
        }
        if (featuredArtistsData[i].includes(foundObject)) {
            continue;
        }
        featuredArtistsData[i].push(foundObject);
    }
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[project]/app/components/PagesContainer.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$spotify$2f$web$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/api/spotify/web.js [app-ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$spotify$2f$web$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__
]);
[__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$spotify$2f$web$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
"use client";
;
;
;
const albumDescriptions = [
    'Trójkąt warszawski spotkał się ze znakomitymi ocenami krytyków muzycznych. Recenzenci chwalili go za błyskotliwe teksty i dobrze dobrane produkcje muzyczne, ciekawie opowiedzianą historię oraz za wprowadzenie nowości na polski rynek muzyczny. Album po czasie odniósł sukces komercyjny, odnotowując wysokie wyniki odtworzeń w serwisach streamingowych i debiutując na trzecim miejscu ogólnopolskiej listy sprzedaży OLiS.',
    'Marmur to pierwszy album studyjny Taco Hemingwaya, stanowiący konceptualne słuchowisko osadzone w fikcyjnym, tajemniczym Hotelu Marmur w Trójmieście. Album jest mroczniejszy i bardziej melancholijny od poprzednich wydawnictw, a jego spójna narracja, pełna trafnych metafor i obserwacji, czyni go czymś w rodzaju muzycznej powieści.',
    '"0,25 mg" to mixtape duetu Taconafide (Taco Hemingway i Quebonafide), który pierwotnie ukazał się w 2018 roku jako bonus do ich głównego albumu, "Soma 0,5 mg". Mimo swojej pierwotnie dodatkowej natury, materiał ten zawiera kilkanaście pełnoprawnych utworów, utrzymanych w konwencji rapu i hip-hopu, stanowiąc równorzędną część kolaboracji.',
    '"Café Belga" to drugi długogrający album Taco Hemingwaya, zaskakująco wypuszczony bez wcześniejszych zapowiedzi. Album, nagrany w Brukseli i Warszawie, wplecione ma fragmenty wywiadu udzielonego przez rapera w tytułowej kawiarni, co nadaje mu formę spójnego słuchowiska. Muzycznie łączy hip-hop z elementami trapu i popu.',
    'Jarmark to czwarta studyjna płyta artysty, która stanowi mocną, często krytyczną recenzję współczesnej Polski, jej historii po transformacji i mentalności społecznej. Pod względem muzycznym to hip-hop z wpływami alternatywnymi, który bywa odbierany przez krytyków jako nierówny, ale lirycznie sprawny i pełen społecznych obserwacji.',
    '“1-800-OŚWIECENIE” to album konceptualny, ale nie w charakterze fabularnym, tak jak było to w przypadku wcześniejszego “Marmuru”. Na nową płytę składa się 15 premierowych utworów, a sam album w zaledwie dobę po starcie preorderu osiągnął złoty nakład (ponad 15 tys. sprzedanych egzemplarzy).'
];
const PagesContainer = ({ activeIndex, setActiveIndex })=>{
    const ContainerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (ContainerRef.current) {
            setTimeout(()=>{
                const totalChildren = ContainerRef.current.children.length;
                const pageCount = totalChildren - 1;
                const newIndexes = [
                    ...Array(pageCount).keys()
                ];
                setPageIndexes(newIndexes);
                console.log(`Liczba zliczonych stron: ${pageCount}.`);
            }, 0);
        }
    }, []);
    // Obliczanie transformacji
    const transformStyle = `translateX(-${activeIndex * 100}vw)`;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ContainerRef,
        id: "app",
        style: {
            transform: transformStyle
        },
        className: "absolute left-0 top-0 grid auto-cols-[100vw] grid-rows-1 grid-flow-col h-full w-full overflow-visible transition-all duration-420 ease-in-out",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(MainPage, {}, void 0, false, {
                fileName: "[project]/app/components/PagesContainer.js",
                lineNumber: 46,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$spotify$2f$web$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["albumsData"].map((_, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(AlbumPage, {
                    albumInfo: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$spotify$2f$web$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["albumsData"][index],
                    albumDescription: albumDescriptions[index],
                    featuredArtists: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$api$2f$spotify$2f$web$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["featuredArtistsData"][index]
                }, index, false, {
                    fileName: "[project]/app/components/PagesContainer.js",
                    lineNumber: 49,
                    columnNumber: 17
                }, ("TURBOPACK compile-time value", void 0)))
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/PagesContainer.js",
        lineNumber: 39,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = PagesContainer;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/app/components/Nigga.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$navigator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/navigator.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$PagesContainer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/PagesContainer.js [app-ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$PagesContainer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__
]);
[__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$PagesContainer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
"use client";
;
;
;
;
const Nigga = ()=>{
    const [activeIndex, setActiveIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [pageIndexes, setPageIndexes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$PagesContainer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                activeIndex: activeIndex,
                setActiveIndex: setActiveIndex
            }, void 0, false, {
                fileName: "[project]/app/components/Nigga.js",
                lineNumber: 14,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$navigator$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                activeIndex: activeIndex,
                setActiveIndex: setActiveIndex,
                pageIndexes: pageIndexes
            }, void 0, false, {
                fileName: "[project]/app/components/Nigga.js",
                lineNumber: 16,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
const __TURBOPACK__default__export__ = Nigga;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    else {
        if ("TURBOPACK compile-time truthy", 1) {
            if ("TURBOPACK compile-time truthy", 1) {
                module.exports = __turbopack_context__.r("[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)");
            } else //TURBOPACK unreachable
            ;
        } else //TURBOPACK unreachable
        ;
    }
} //# sourceMappingURL=module.compiled.js.map
}),
"[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-ssr] (ecmascript)").vendored['react-ssr'].ReactJsxDevRuntime; //# sourceMappingURL=react-jsx-dev-runtime.js.map
}),
"[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-ssr] (ecmascript)").vendored['react-ssr'].React; //# sourceMappingURL=react.js.map
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__ab497f4c._.js.map