"use client"

import { useState} from "react";

import Navigator from "./navigator";
import PagesContainer from "./PagesContainer";

export default function Home() {
    const [activeIndex, setActiveIndex] = useState(0);
    const [pageIndexes, setPageIndexes] = useState([]); 
    return (
       <>
        <PagesContainer activeIndex={activeIndex} setActiveIndex={setActiveIndex} setPageIndexes={setPageIndexes}/>

        <Navigator activeIndex={activeIndex} setActiveIndex={setActiveIndex} pageIndexes={pageIndexes}/>
        </>
    );
}